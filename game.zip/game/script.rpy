﻿default strange = 0
default gold = 10600
# Определение персонажей
define o = Character('ОП', color="#c8ffc8")
define s = Character('Sasha', color="#1e88e5")
define t = Character('ТП', color="#228B22")
define v = Character('Vика', color="#ff591f")
define p = Character("[name]")
# Объявление фонов с правильным масштабированием (ATL вместо старого im.FactorScale)
image start:
    "images/start.png"
    zoom 2.8

image yard:
    "images/yard.png"
    zoom 1.5

image o normal = "images/op.png"
image s normal = "images/sasha.png"
image t normal = "images/tp.png"
image v normal = "images/v.png"
image p normal = "images/p.png"
image t surp = "images/tpsurp.png"

# Игра начинается здесь:
label start:
    # Показываем стартовый фон
    scene start

    # Показываем персонажа слева
    show o normal at left
    default name = "Миша"
    o "Мы едем в Лобаново."
    $ name = renpy.input("Как тебя зовут?", default="Миша")

    # Показываем Сашу справа
    show s normal at right
    s "Я надеюсь, всё будет хорошо"
    o "Я тоже"

    hide s normal
    o "Ну что, едем"

    # Переход на локацию двора
    jump yard

label yard:
    scene yard

    o "Мы приехали"

    show t normal at left:
        zoom 0.6

    t "Здравствуйте!"

    t "У нас в Лобанове проблемы!"

    "Елена всегда помогала проекту."

    t "Вода чёрная из-под крана."

    show s normal at right

    s "Наверное что-то с трубами"

    $ name1 = renpy.input("Как зовут твоего друга?", default="Миша")

    s "Деревня старая"

    menu:
        "Я пойду в дом. Хорошо что я принёс воду":
            jump home

        "Это нельзя объяснить":
            $ strange += 1
            "Это очень страшно"
    jump home
    return