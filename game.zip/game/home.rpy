# home.rpy
image home:
    "images/home.png"
    zoom 1.0
image basement:
    "images/basement.jpeg"
    zoom 1.5
label home:
    scene home
    "Дом"

    "Похоже вы начали свой путь [strange]"

    "В кармане [gold]"

    show t normal at center
    show s normal at left

    t "Воду надо экономить"

    hide t normal

    "Это очень сложно"


    s "А где Вика?"

    show t surp at left

    t "Вика? Я сама не знаю где она"

    s "А что случилось?"

    hide t surp

    show t normal at center

    show o normal at right

    o "Здравствуйте!"

    hide o normal

    show v normal at right

    v "Я пришла!"

    v "Я чуть не заблудилась"

    s "Понятно. Ты воду экономишь?"

    v "Да, а ты сам принёс бутылку воды?"

    s "Я не знал, но принёс!"

    t "Саша раньше вода была!"

    s "Что с ней стало?"

    t "Пойдём в подвал! Я тебе расскажу. Ты должен увидеть"

    jump basement
    return
label basement:
    scene basement

    t "Я хочу свой колодец с водой, но вода там тоже может быть чёрная!"

    show p normal at center

    p "Правда?"

    p "Здравствуйте! Вода чёрная?"

    s "Да"

    hide p normal

    show s normal at center
    show t surp at left

    t "Всё начилось весной. У нас дома вода была солёная, а потмо она стала чёрной."

    t "После этого у нас в Лобанове девушка пропала. Ночью у нас электричество ограничено. Мы испольузем генератор"

    t ""
return